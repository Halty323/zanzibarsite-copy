<?php
declare(strict_types=1);

require_once 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Enable CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, indexing');
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Authentication middleware
function authenticate(): bool {
    $headers = getallheaders();
    return isset($headers['indexing']) && $headers['indexing'] === 'authorizationEnabled';
}

// Send JSON response
function sendResponse($data, int $statusCode = 200): void {
    http_response_code($statusCode);
    echo json_encode($data);
    exit();
}

// Send plain text response
function sendTextResponse(string $text, int $statusCode = 200): void {
    http_response_code($statusCode);
    header('Content-Type: text/plain');
    echo $text;
    exit();
}

// Build file tree recursively
function buildFileTree(string $dirPath, string $prefix = ''): string {
    $result = '';
    if (!is_dir($dirPath)) {
        return $result;
    }

    $files = scandir($dirPath);
    $dirs = array_filter($files, function($file) use ($dirPath) {
        return $file !== '.' && $file !== '..' && is_dir($dirPath . '/' . $file);
    });

    $dirs = array_values($dirs); // Reset array keys

    foreach ($dirs as $index => $dir) {
        $isLast = $index === count($dirs) - 1;
        $connector = $isLast ? '└── ' : '├── ';
        $nextPrefix = $isLast ? '    ' : '│   ';

        $result .= $prefix . $connector . $dir . "\n";
        $result .= buildFileTree($dirPath . '/' . $dir, $prefix . $nextPrefix);
    }

    return $result;
}

// Route handling
$method = $_SERVER['REQUEST_METHOD'];
$path = $_SERVER['REQUEST_URI'];

switch ($path) {
    case '/send-email':
        if ($method !== 'POST') {
            sendResponse(['error' => 'Method not allowed'], 405);
        }

        // Parse JSON input
        $input = json_decode(file_get_contents('php://input'), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            sendResponse(['error' => 'Invalid JSON'], 400);
        }

        $firstName = $input['first-name'] ?? '';
        $lastName = $input['last-name'] ?? '';
        $email = $input['email'] ?? '';
        $telephone = $input['telephone'] ?? '';
        $subject = $input['subject'] ?? '';
        $message = $input['comment'] ?? '';

        // Basic validation
        if (empty($email) || empty($subject) || empty($message)) {
            sendResponse(['error' => 'Missing required fields'], 400);
        }

        // Email configuration
        $mail = new PHPMailer(true);

        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'mail.hosting.reg.ru';
            $mail->SMTPAuth = true;
            $mail->Username = 'applications@zanzibaronline.online';
            $mail->Password = 'kV1nF0bZ1etP2vW3';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;

            // Recipients
            $mail->setFrom($email, $firstName . ' ' . $lastName);
            $mail->addAddress('applications@zanzibaronline.online');

            // Content
            $mail->isHTML(false);
            $mail->Subject = 'Contact Form Submission: ' . $subject;
            $mail->Body = "Name: $firstName $lastName\nEmail: $email\nTelephone: $telephone\nMessage: $message";

            $mail->send();
            sendResponse(['message' => 'Email sent successfully']);
        } catch (Exception $e) {
            error_log('Email sending failed: ' . $mail->ErrorInfo);
            sendResponse(['error' => 'Failed to send email: ' . $mail->ErrorInfo], 500);
        }
        break;

    case '/upload':
        if ($method !== 'POST') {
            sendResponse(['error' => 'Method not allowed'], 405);
        }

        if (!authenticate()) {
            sendResponse(['error' => 'Unauthorized'], 401);
        }

        if (!isset($_FILES['file'])) {
            sendResponse(['error' => 'No file uploaded'], 400);
        }

        $file = $_FILES['file'];
        $uploadPath = __DIR__ . '/../' . basename($file['name']);

        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            sendResponse(['message' => 'File uploaded successfully']);
        } else {
            sendResponse(['error' => 'Failed to upload file'], 500);
        }
        break;

    case (preg_match('/^\/delete\/(.+)$/', $path, $matches) ? $path : ''):
        if ($method !== 'DELETE') {
            sendResponse(['error' => 'Method not allowed'], 405);
        }

        if (!authenticate()) {
            sendResponse(['error' => 'Unauthorized'], 401);
        }

        $filename = $matches[1];
        $filePath = __DIR__ . '/../' . $filename;

        if (!file_exists($filePath)) {
            sendResponse(['error' => 'File not found'], 404);
        }

        if (unlink($filePath)) {
            sendResponse(['message' => 'File deleted successfully']);
        } else {
            sendResponse(['error' => 'Error deleting file'], 500);
        }
        break;

    case (preg_match('/^\/delete-folder\/(.+)$/', $path, $matches) ? $path : ''):
        if ($method !== 'DELETE') {
            sendResponse(['error' => 'Method not allowed'], 405);
        }

        if (!authenticate()) {
            sendResponse(['error' => 'Unauthorized'], 401);
        }

        $foldername = $matches[1];
        $folderPath = __DIR__ . '/../' . $foldername;

        if (!is_dir($folderPath)) {
            sendResponse(['error' => 'Folder not found'], 404);
        }

        // Remove directory recursively
        $files = array_diff(scandir($folderPath), ['.', '..']);
        foreach ($files as $file) {
            $filePath = $folderPath . '/' . $file;
            if (is_dir($filePath)) {
                rmdir_recursive($filePath);
            } else {
                unlink($filePath);
            }
        }

        if (rmdir($folderPath)) {
            sendResponse(['message' => 'Folder deleted successfully']);
        } else {
            sendResponse(['error' => 'Error deleting folder'], 500);
        }
        break;

    case '/files':
        if ($method !== 'GET') {
            sendResponse(['error' => 'Method not allowed'], 405);
        }

        if (!authenticate()) {
            sendResponse(['error' => 'Unauthorized'], 401);
        }

        try {
            $rootPath = __DIR__ . '/../';
            $fileTree = buildFileTree($rootPath);
            sendTextResponse($fileTree);
        } catch (Exception $e) {
            sendResponse(['error' => 'Error reading file tree'], 500);
        }
        break;

    default:
        sendResponse(['error' => 'Not found'], 404);
        break;
}

// Helper function for recursive directory removal
function rmdir_recursive(string $dir): bool {
    $files = array_diff(scandir($dir), ['.', '..']);
    foreach ($files as $file) {
        $filePath = $dir . '/' . $file;
        if (is_dir($filePath)) {
            rmdir_recursive($filePath);
        } else {
            unlink($filePath);
        }
    }
    return rmdir($dir);
}