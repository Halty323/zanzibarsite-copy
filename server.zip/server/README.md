# Hidden Garden Zanzibar - PHP Server

This is a PHP 8.2.28 rewrite of the original Node.js/Express server for the Hidden Garden Zanzibar project.

## Features

- **Email sending** - Contact form submissions via PHPMailer
- **File upload** - Secure file upload with authentication
- **File management** - Delete files and folders with authentication
- **File tree browsing** - View directory structure with authentication
- **CORS support** - Cross-origin resource sharing enabled
- **Authentication** - Header-based authentication system

## Requirements

- PHP 8.2.28 or higher
- Composer (for dependency management)
- Web server with PHP support (Apache, Nginx, or built-in PHP server)

## Installation

1. Navigate to the server directory:
   ```bash
   cd server
   ```

2. Install dependencies using Composer:
   ```bash
   composer install
   ```

3. Configure email settings in `server.php`:
   - Update the Gmail credentials in the email configuration section
   - Set up an App Password for Gmail if using 2FA

## Configuration

### Email Settings
Edit the email configuration in `server.php`:

```php
$mail->Username = 'your-email@gmail.com';
$mail->Password = 'your-app-password'; // Use App Password, not regular password
```

### Authentication
The server uses header-based authentication. Include the following header in authenticated requests:
```
indexing: authorizationEnabled
```

## Running the Server

### Option 1: Built-in PHP Server (Development)
```bash
php -S localhost:3000 server.php
```

### Option 2: Apache/Nginx
Configure your web server to point to the server directory and route requests to `server.php`.

For Apache, you may need to add to your `.htaccess`:
```apache
RewriteEngine On
RewriteRule ^(.*)$ server.php [QSA,L]
```

## API Endpoints

### POST /send-email
Send contact form emails.

**Request Body:**
```json
{
    "first-name": "John",
    "last-name": "Doe",
    "email": "john@example.com",
    "telephone": "+1234567890",
    "subject": "Contact Request",
    "comment": "Message content"
}
```

### POST /upload
Upload files (requires authentication).

**Headers:**
```
indexing: authorizationEnabled
Content-Type: multipart/form-data
```

### DELETE /delete/{filename}
Delete a file (requires authentication).

### DELETE /delete-folder/{foldername}
Delete a folder recursively (requires authentication).

### GET /files
Get file tree structure (requires authentication).

## Security Notes

- All file operations require authentication
- File uploads are saved to the parent directory
- Email credentials should be properly secured
- Consider implementing additional security measures for production

## Migration from Node.js

This PHP version maintains the same API endpoints and functionality as the original Node.js server:

- Same authentication mechanism
- Identical request/response formats
- Equivalent file handling capabilities
- Same email functionality using PHPMailer instead of Nodemailer

## Troubleshooting

1. **Email not sending**: Check Gmail App Password setup and credentials
2. **File permissions**: Ensure PHP has write permissions for file operations
3. **CORS issues**: CORS headers are already configured, check browser console for errors
4. **Authentication failures**: Verify the `indexing` header is correctly set